﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WildFarm2._0;

public class Seeds : BaseFood
{
    public Seeds(int quantity) : base(quantity)
    {
    }
}