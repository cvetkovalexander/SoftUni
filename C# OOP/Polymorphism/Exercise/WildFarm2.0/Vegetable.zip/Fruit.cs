﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WildFarm2._0;

public class Fruit : BaseFood
{
    public Fruit(int quantity) : base(quantity)
    {
    }
}