﻿namespace AccessControlSystem.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
