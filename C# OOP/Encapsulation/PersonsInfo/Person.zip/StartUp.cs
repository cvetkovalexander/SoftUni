﻿using System.Data;

namespace PersonsInfo;

public class StartUp
{
    static void Main()
    {
    }
}