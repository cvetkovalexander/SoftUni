﻿namespace CyberSecurityDS.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
