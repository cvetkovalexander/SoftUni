﻿namespace NetPay.Data;

public class Configuration
{
    public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=NetPay;Trusted_Connection=True;Encrypt=False;";
}
