﻿namespace SocialNetwork.Data;

public class Configuration
{
    public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=SocialNetwork;Trusted_Connection=True;Encrypt=False;";
}
